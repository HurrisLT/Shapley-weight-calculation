import os
import shutil

from pyspark import SparkContext
from pyspark.ml.classification import LogisticRegression, DecisionTreeClassifier
from pyspark.ml.classification import LogisticRegressionModel, DecisionTreeClassificationModel
from pyspark.sql import SparkSession
from pyspark.ml.feature import VectorAssembler
import zipfile
import base64


# Load training data

#reading txt data
#training = spark.read.format("libsvm").load("./data/sample_libsvm_data.txt")

#reading csv data
sc = SparkContext("local", "First App")
spark = SparkSession.builder.appName("LogisticRegression").config("spark.some.config.option", "some-value").getOrCreate()
path = "./data/dataEEG1024.json"
rawDF = spark.read.load(path, format="json", multiLine="true")
rawDF.printSchema()

assemblerFeatures = VectorAssembler(
    inputCols=["data0",  "data1", "data2",  "data3", "data4", "data5", "data6", "data7",
               "data8", "data9", "data10", "data11", "data12", "data13"],
    outputCol='features')

trainingDF = assemblerFeatures.transform(rawDF)
trainingDF.show()


lr = LogisticRegression(maxIter=10, regParam=0.3, elasticNetParam=0.8)
dt = DecisionTreeClassifier(featuresCol ='features', labelCol ='label', maxDepth = 3)
dtModel = dt.fit(trainingDF)
# Fit the model
lrModel = lr.fit(trainingDF)

splits = trainingDF.randomSplit([1.0,1.0,1.0,1.0,1.0])
testDF = trainingDF.randomSplit([1.0,1.0])
modelFileName = "LRModel"
tempModelDir = "./LRModels/tempDTmodel"
tempZipDir = "./LRModels/tempzipdir"
zipFileName = "/LRzip"
fullZipFilePath = tempZipDir + zipFileName
for splitDF in splits:
    os.mkdir(tempZipDir)
    tempDTC = LogisticRegression(featuresCol='features', labelCol='label')
    tempDTCModel = tempDTC.fit(splitDF)
    # Select example rows to display.
    predictions = tempDTCModel.transform(testDF[0])
    # predictions.select("label", "probability").show(20)
    tempDTCModel.save(tempModelDir)

    persistedModel = LogisticRegressionModel.load(tempModelDir)
    predictionLR = persistedModel.transform(trainingDF)
    selected = predictionLR.select("features", "label", "rawPrediction", "prediction", "probability")


    shutil.make_archive(fullZipFilePath, 'zip', tempModelDir)
    with open(fullZipFilePath+".zip", "rb") as f:
        zip_bytes = f.read()
        encoded = base64.urlsafe_b64encode(zip_bytes)
        print(encoded)
    #if os.path.exists(tempModelDir):
    #shutil.rmtree(tempModelDir)
    #shutil.rmtree(tempZipDir)


# Print the coefficients and intercept for logistic regression
#print("Coefficients: " + str(lrModel.coefficients))
#print("Intercept: " + str(lrModel.interceptVector))

# Make predictions.
predictions = dtModel.transform(trainingDF)

# Select example rows to display.
predictions.select("prediction", "label","probability").show(5)

#lrModel.save("./models/dt_model.model")



with open("./modelsFromChaincode/lrm_model.model.zip", "rb") as f:
    zip_bytes = f.read()
    encoded = base64.urlsafe_b64encode(zip_bytes)
    print(encoded)
    with open("./models/bytes.txt", "wb") as f:
        f.write(encoded)

try:
   file_content=base64.urlsafe_b64decode(encoded)
   print(file_content)
   with open("./models/modelsDecodedModel.zip", "wb") as f:
        f.write(file_content)
except Exception as e:
   print(str(e))

#unzipping a file
with zipfile.ZipFile('./modelsFromChaincode/lrm_model.model.zip', 'r') as zip_ref:
    zip_ref.extractall('./unzippedModels')

persistedModel = LogisticRegressionModel.load("./unzippedModels/lrm_model.model")
predictionLR = persistedModel.transform(trainingDF)
selected = predictionLR.select("features", "label", "rawPrediction", "prediction","probability")
#for row in selected.collect():
#    print(row)

